package servidor;

import java.io.Serializable;

public class Pessoa implements Serializable {
	private static final 
	String nome;
	String email;
	
	public Pessoa(String nome, String email) {
		super();
		this.nome = nome.trim();
		this.email = gerarEmail();
	}
	
	public Pessoa() {
		
	}
	
	private String gerarEmail() {
		String palavras[];
		palavras = this.nome.split(" ");
		String email = palavras[0] + "." + palavras[palavras.length-1] + "@ufn.edu.br";
	}
	
}
