package servidor;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IGerarEmail extends Remote {
	public Pessoa gerarEmail(String s) throws RemoteException;
}
