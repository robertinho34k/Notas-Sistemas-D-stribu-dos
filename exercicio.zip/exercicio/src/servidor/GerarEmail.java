package servidor;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class GerarEmail extends UnicastRemoteObject implements IGerarEmail {
	public GerarEmail() throws RemoteException{
		
	}
	
	@Override
	public Pessoa gerarEmail(String s) throws RemoteException {
		Pessoa p = new Pessoa(s);
		
		return p;
	}
	
}
