package cliente;

import java.rmi.Remote;
import java.rmi.RemoteException;
import servidor.Pessoa;

public interface IGerarEmail extends Remote {
	public Pessoa gerarEmail(String s) throws RemoteException;
}
