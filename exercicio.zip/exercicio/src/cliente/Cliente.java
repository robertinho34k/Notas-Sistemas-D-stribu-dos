
package cliente;

import java.rmi.Naming;
import javax.swing.JOptionPane;

public class Cliente {

    public static void main(String[] args) {
        try {
            IGerarEmail c = (IGerarEmail) Naming.lookup("rmi://localhost/ServerString");
            String frase = JOptionPane.showInputDialog("Digite um nome completo: ");
            pessoa p = c.gerarEmail(frase); 
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }

}